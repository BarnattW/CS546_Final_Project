Run "npm run seed" to first seed the database
Run "npm start" to run the application

Credentials for seeded users are inside the utils/seed.js file but here
are some credentials:

Customers:
username: barneywoo
password: 12345678

username: fischer
password: Password123

Sellers:
username: furni_world123
password: Comfort2024!

username: urban1
password: 12345678